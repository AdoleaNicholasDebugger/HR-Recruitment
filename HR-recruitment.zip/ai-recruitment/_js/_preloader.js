function owlphinhome(){
	$("#loader-starter").fadeIn(200);
	window.location = "../bacsyd";
}
function login(){
	$("#loader-starter").fadeIn(200);
	window.location = "login";
}
function register(){
	$("#loader-starter").fadeIn(200);
	window.location = "register";
}
function resetpass(){
	$("#loader-starter").fadeIn(200);
	window.location = "reset-pass";
}
function contact(){
	$("#loader-starter").fadeIn(200);
	window.location = "contact-us";
}
function sync(user){
	$("#loader-starter").fadeIn(200);
	window.location = "sync&"+user;
}
function profile(user){
	$("#loader-starter").fadeIn(200);
	window.location = "profile&"+user;
}
function notifications(user){
	$("#loader-starter").fadeIn(200);
	window.location = "notifications&"+user;
}
function settings(user){
	$("#loader-starter").fadeIn(200);
	window.location = "settings&"+user;
}
function jobs(user){
	$("#loader-starter").fadeIn(200);
	window.location = "jobs&"+user;
}
function rjob(user){
	$("#loader-starter").fadeIn(200);
	window.location = "r-job&"+user;
}
function bookmarks(user){
	$("#loader-starter").fadeIn(200);
	window.location = "bookmarks&"+user;
}
function recruiter(user){
	$("#loader-starter").fadeIn(200);
	window.location = "recruiter&"+user;
}
function logout(){
	$("#loader-starter").fadeIn(200);
	window.location = "_parse/_logout.php";
}
function help(){
	$("#loader-starter").fadeIn(200);
	window.location = "help";
}
function admin(){
	$("#loader-starter").fadeIn(200);
	window.location = "admin";
}