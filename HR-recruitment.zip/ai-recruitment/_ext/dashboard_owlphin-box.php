<div class="owlphin-box">
	<div class="chat"></div>
	<div class="input has-feedback">
		<!--<textarea type="text" placeholder="Lets chat!"></textarea><a>Send</a>-->	
		<div class="input-append">
          <input class="span2 m-wrap" id="appendedInputButton" placeholder="Start typing.." type="text">
          <a class="btn" style="margin-left: 2px;"><span class="fa fa-send"></span></a>
        </div>                                    	
	</div>
	<div class="busy"></div>
</div>