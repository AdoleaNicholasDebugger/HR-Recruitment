	<div  id="loader-starter" class="page-loader-wrapper">
		<div class="loader">
			<div class="preloader">
				<!-- <img class="theowl" src="_img/owlphin_gif.gif" style="height:30px;" /> -->
				<div class="spinner" style="background-color: #fff;width: 160px;height: 160px;"></div>
			</div>
		   <p style="color:#b3b3b3;">Please wait...</p>
		</div>
	</div>