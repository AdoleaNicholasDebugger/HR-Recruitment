<?php
	header("location: ../");
	exit();
?>